import React from "react";
import Hemisphere_Display from "./HemisphereDisplay";

class App extends React.Component {
    /*
    constructor(props){
        super(props)
        this.state ={latitude:""}
        window.navigator.geolocation.getCurrentPosition(
            (position) => {
                this.setState({latitude: position.coords.latitude})
            }
        )
    }
    */

    state = { latitude: '' }
    componentDidMount() {
        window.navigator.geolocation.getCurrentPosition(
            (position) => {
                this.setState({ latitude: position.coords.latitude })
            }
        )
    }
    render() {

        return (
            <div> 
                <Hemisphere_Display latitude={this.state.latitude} />
            </div>

        )
    }
}

export default App;
