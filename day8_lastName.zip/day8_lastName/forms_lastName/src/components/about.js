import React from "react";

const About = function(){
    return(
        <div className="ui raised very padded text container segment" style={{marginTop:'3em'}}>
            <h2 className="ui header">About us</h2>
            <p>Some text about us</p>
        </div>
    )
}

export default About;